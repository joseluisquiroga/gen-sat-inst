/* 
 * (C) Tuomo Pyh�l�
 */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "adder.h"
#include "output-format.h"

void printbitset(FILE *outf, char *set, char *prefix) {
  int first = 1;
  int i;
  
  if(set != NULL) {
    fprintf(outf, "SET{");
    for(i=0; set[i]; i++) {
      switch(set[i]) {
      case '1':
	  if(!first) 
	    fprintf(outf, ",");
	  else
	    first = 0;
	  fprintf(outf, "%s%d", prefix, i);
	break;
      case '0':
	  if(!first)
	    fprintf(outf, ",");
	  else 
	    first = 0;
	  fprintf(outf, "~%s%d", prefix, i);
	break;
      case '?':
	  break;
      default:
	fprintf(stderr, "Syntax error\n");
	break;
      }
    }
    fprintf(outf, "};\n");
  }
}


int main(int argc, char *argv[]) {
  int width = 1;
  int size = 1;
  int levelcount;
  char *augend = NULL;
  char *addend = NULL;
  char *sum = NULL;
  int carryin = -1;
  int carryout = -1;
  FILE *outfile = stdout;
  int i,j;
  char c;
  char *optstring = "a:b:s:i:o:w:f:";
  char **inlines;

  while((c = getopt(argc, argv, optstring))!= EOF) {
    switch(c) {
    case 'a':
      augend = optarg;
      break;
    case 'b':
      addend = optarg;
      break;
    case 's':
      sum = optarg;
      break;
    case 'i':
      carryin = atoi(optarg);
      break;
    case 'o':
      carryout = atoi(optarg);
      break;
    case 'w':
      if((width = atoi(optarg))==0) {
	fprintf(stderr, "Width == 0\n");
	return 2;
      }
      
      break;
    case 'f':
      if((outfile = fopen(optarg, "w"))==NULL) {
	fprintf(stderr, "Error while opening %s\n", optarg);
	return 1;
      }
    }
  }
  
  set_output_format(0);

  inlines = new char*[width*2];
  for(i=0; i<width; i++) {
    inlines[i] = new char[width+1];
    inlines[width+i] = new char[width+1];
    sprintf(inlines[i], "a%d", i);
    sprintf(inlines[width+i], "b%d", i);
  }
  printadder(outfile, width, inlines, "adder");


  printbitset(outfile, augend, "a");
  printbitset(outfile, addend, "b");
  printbitset(outfile, sum, "adder_sum");
  
  if(carryin == 0)
    fprintf(outfile, "SET{~carry0};\n");
  if(carryin == 1)
    fprintf(outfile, "SET{carry0};\n");

  if(carryout == 0)
    fprintf(outfile, "SET{~adder_carryout};\n");

  if(outfile != stdout) {
    fclose(outfile);
  }
}















