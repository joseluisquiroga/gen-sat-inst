#ifndef OUTPUT_FORMAT_H
#include <stdio.h>
#define OUTPUT_FORMAT_H

typedef struct _line_t {
  char *name;
  int not;
} line_t;


typedef void (*gate_print_f)(FILE *outf, line_t, int count, ...);
typedef void (*set_line_t)(FILE *outf, line_t);
typedef void (*set_equal_t)(FILE *outf, line_t, line_t);
typedef void (*initialize_t)(FILE *outf);
typedef void (*set_choice_t)(FILE *outf, line_t);

typedef struct _output_format_t {
  char *name;
  gate_print_f and_pf;
  gate_print_f or_pf;
  gate_print_f xor_pf;
  set_line_t sl_f;
  set_equal_t se_f;
  initialize_t init_f;
  set_choice_t choice_f;
} output_format_t;

extern gate_print_f print_or;
extern gate_print_f print_and;
extern gate_print_f print_xor;
extern set_line_t set_line;
extern set_equal_t set_equal;
extern set_choice_t set_choice;
char *get_output_format_name(int n);
int set_output_format(FILE *, int n);
void print_or_table(FILE *, line_t, line_t[], int);
void print_and_table(FILE *, line_t, line_t[], int);
void print_xor_table(FILE *, line_t, line_t[], int);

#endif
