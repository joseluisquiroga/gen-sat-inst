/*
 Copyright (C) 2002 Tommi A. Junttila
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2
 as published by the Free Software Foundation.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdlib.h>
#include "gatehash.hh"

GateHash::Entry::Entry(Gate *g, Entry *n, Entry *p) :
  gate(g), next(n), prev(p)
{
}

GateHash::GateHash(int n_rows) {
  DEBUG_ASSERT(n_rows > 0);
  nof_rows = n_rows;
  rows = (Entry**)calloc(nof_rows, sizeof(Entry*));
  if(!rows) {
    fprintf(stderr, "Out of memory\n");
    exit(1);
  }
}

GateHash::~GateHash() {
  for(int row = 0; row < nof_rows; row++) {
    Entry *entry = rows[row];
    while(entry) {
      Entry *next = entry->next;
      delete entry;
      entry = next;
    }
  }
  free(rows);
}

Gate *GateHash::test_and_set(Gate *gate) {
  unsigned int row = gate->hash_value() % nof_rows;
  Entry *entry = rows[row];
  while(entry) {
    if(entry->gate->comp(gate) == 0)
      break;
    entry = entry->next;
  }
  if(entry) return entry->gate;
  Entry *new_entry = new Entry(gate, rows[row], 0);
  if(rows[row])
    rows[row]->prev = new_entry;
  rows[row] = new_entry;
  return gate;
}

bool GateHash::is_in(Gate *gate) {
  unsigned int row = gate->hash_value() % nof_rows;
  Entry *entry = rows[row];
  while(entry) {
    if(entry->gate == gate)
      break;
    entry = entry->next;
  }
  return(entry != 0);
}

