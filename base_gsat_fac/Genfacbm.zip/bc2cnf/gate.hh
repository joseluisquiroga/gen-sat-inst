/*
 Copyright (C) 2002 Tommi A. Junttila
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2
 as published by the Free Software Foundation.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef GATE_HH
#define GATE_HH

class Gate;
class ChildAssoc;

#include <list.h>
#include <vector.h>
#include "defs.hh"
#include "gatehash.hh"
#include "bc.hh"

class Gate {
  void init();

public:
  typedef enum {tEQUIV = 0, tOR, tAND, tEVEN, tODD, tITE,
                tNOT, tTRUE, tFALSE, tVAR, tTHRESHOLD, tATLEAST,
                tREF, tUNDEF, tDELETED, tNOFTYPES} Type;
  static const char *typeNames[tNOFTYPES];

  Type type;
  list<char*> names;
  ChildAssoc *children, *fathers;
  unsigned int tmin, tmax;
  int temp;

  Gate(Type);
  Gate(Type, char *name);
  Gate(Type, Gate *child);
  Gate(Type, Gate *child1, Gate *child2);
  Gate(Type, Gate *if_gate, Gate *then_gate, Gate *else_gate);
  Gate(Type, list<Gate*> *childs);
  ~Gate();

  void share(BC *bc, GateHash *ht);
  void simplify(BC *bc);
  void normalize(BC * const bc);
  int cnf_count_clauses();
  void cnf_print_clauses(FILE *fp);

  unsigned int hash_value();
  int comp(const Gate *gate2) const;
  void sort_children();
  unsigned int count_children();
  void add_child(Gate *child);
  void remove_all_children();
  int test_acyclicity(list<char*> &cycle);
};


class ChildAssoc {
public:
  Gate *child;
  Gate *father;

  ChildAssoc *prev_child, *next_child;
  ChildAssoc *prev_father, *next_father;

  ChildAssoc(Gate *father, Gate *child);
  ~ChildAssoc();
  void change_child(Gate *new_child);
  void change_father(Gate *new_father);

  void link_father(Gate *father);
  void link_child(Gate *child);
  void unlink_father();
  void unlink_child();
};

#endif
