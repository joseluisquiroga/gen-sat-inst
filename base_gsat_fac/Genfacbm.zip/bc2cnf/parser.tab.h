/* A Bison parser, made by GNU Bison 1.875d.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     LPAREN = 258,
     RPAREN = 259,
     LBRACKET = 260,
     RBRACKET = 261,
     SEMICOLON = 262,
     COMMA = 263,
     DEF = 264,
     ASSIGN = 265,
     ITEf = 266,
     NOTf = 267,
     EVENf = 268,
     ODDf = 269,
     ANDf = 270,
     ORf = 271,
     IMPLYf = 272,
     EQUIVf = 273,
     EQUIV = 274,
     IMPLY = 275,
     OR = 276,
     AND = 277,
     ODD = 278,
     NOT = 279,
     ID = 280,
     TRUE = 281,
     FALSE = 282,
     NUM = 283
   };
#endif
#define LPAREN 258
#define RPAREN 259
#define LBRACKET 260
#define RBRACKET 261
#define SEMICOLON 262
#define COMMA 263
#define DEF 264
#define ASSIGN 265
#define ITEf 266
#define NOTf 267
#define EVENf 268
#define ODDf 269
#define ANDf 270
#define ORf 271
#define IMPLYf 272
#define EQUIVf 273
#define EQUIV 274
#define IMPLY 275
#define OR 276
#define AND 277
#define ODD 278
#define NOT 279
#define ID 280
#define TRUE 281
#define FALSE 282
#define NUM 283




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 21 "parser.y"
typedef union YYSTYPE {
  char *charptr;
  int intval;
  Gate *gate;
  list<Gate*> *list;
} YYSTYPE;
/* Line 1285 of yacc.c.  */
#line 100 "parser.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE cplval;



