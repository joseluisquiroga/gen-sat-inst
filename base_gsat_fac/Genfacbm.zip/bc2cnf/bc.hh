/*
 Copyright (C) 2002 Tommi A. Junttila
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2
 as published by the Free Software Foundation.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef BC_HH
#define BC_HH

class BC;

#include <stdio.h>
#include <vector.h>
#include "defs.hh"
#include "gate.hh"

class BC {
public:
  vector<Gate*> gates;
  list<char*> constrained_to_true, constrained_to_false;

  BC();

  static BC *parse_circuit(FILE *fp);

  void to_dot(FILE *fp);
  void to_cnf(FILE *fp);

  bool test_acyclicity();

  bool changed;
  void share();
  void simplify();
};

#endif
