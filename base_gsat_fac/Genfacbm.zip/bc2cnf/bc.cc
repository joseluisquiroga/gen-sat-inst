/*
 Copyright (C) 2002 Tommi A. Junttila
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2
 as published by the Free Software Foundation.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdlib.h>
#include <ctype.h>
#include <slist.h>
#include <hash_map.h>
#include "defs.hh"
#include "bc.hh"

#define MAX_VERSION_LENGTH 100

BC::BC() {
  while(!gates.empty()) {
    delete gates.back();
    gates.pop_back();
  }
}

BC *BC::parse_circuit(FILE *fp) {
  extern int cplineno;
  extern int cpparse();
  extern int cprestart(FILE *);
  extern void cperror(const char *, ...);
  extern void cperror2(const char *, ...);
  extern hash_map<char *, Gate *, hash<char*>, eqstr> cp_named_gates;
  extern list<char*> cp_true_gate_names;
  extern list<char*> cp_false_gate_names;

  slist<Gate*> gate_stack;

  cp_named_gates.clear();
  cp_true_gate_names.clear();
  cp_false_gate_names.clear();

  BC *circuit = new BC();

  //
  // Read first line
  //
  float version;
  int c;
  /* read header line */
  if((c = getc(fp)) != 'B' ||
     (c = getc(fp)) != 'C')
    cperror2("illegal header line");
  /* read and check circuit version */
  char version_string[MAX_VERSION_LENGTH + 1];
  int version_length = 0;
  while(true) {
    if(version_length >= MAX_VERSION_LENGTH)
      cperror2("too long version number");
    c = getc(fp);
    if(isdigit(c))
      version_string[version_length++] = (char)c;
    else if(c == '.') {
      if(version_length == 0)
	cperror2("invalid version number");
      version_string[version_length++] = (char)c;     
      break;
    }
    else {
      cperror2("invalid version number");
    }
  }
  while(true) {
    if(version_length >= MAX_VERSION_LENGTH)
      cperror2("too long version number");
    c = getc(fp);
    if(isdigit(c))
      version_string[version_length++] = (char)c;
    else {
      ungetc(c, fp);
      break;
    }
  }
  version_string[version_length] = '\0';
  char *endptr;
  version = strtod(version_string, &endptr);
  if(version > (float)1.0)
    cperror2("version %f not handled", version);
  c = getc(fp);
  if(c != '\n')
    cperror2("version number not followed by newline");
  cplineno = 2;
  
  
  //
  // Parse the circuit
  //
  cprestart(fp);
  if(cpparse())
    goto error_exit;

  //
  // Find all the gates
  //
  for(hash_map<char *, Gate *, hash<char*>, eqstr>::iterator ngi = cp_named_gates.begin(); ngi != cp_named_gates.end(); ngi++) {
    gate_stack.push_front((*ngi).second);
  }
  while(!gate_stack.empty()) {
    Gate *gate = gate_stack.front();
    gate_stack.pop_front();
    if(gate->temp != 0)
      continue;
    gate->temp = 1;
    circuit->gates.push_back(gate);
    for(ChildAssoc *ca = gate->children; ca; ca = ca->next_child) {
      Gate *child = ca->child;
      if(child->temp == 0)
	gate_stack.push_front(child);
    }
  }
  for(vector<Gate*>::iterator gi = circuit->gates.begin();
      gi != circuit->gates.end();
      gi++) {
    (*gi)->temp = 0;
  }

  /*
   * Convert all undef gates into variable gates
   */
  for(vector<Gate*>::iterator gi = circuit->gates.begin();
      gi != circuit->gates.end();
      gi++) {
    Gate *gate = *gi;
    if(gate->type == Gate::tUNDEF) {
      DEBUG_ASSERT(gate->children == 0);
      gate->type = Gate::tVAR;
    }
  }

  /*
   * Make constraints
   */
  for(list<char*>::iterator ci = cp_true_gate_names.begin();
      ci != cp_true_gate_names.end();
      ci++) {
    Gate *gate = cp_named_gates[*ci];
    if(gate == 0) {
      fprintf(stderr, "gate '%s' assigned to true but not defined\n", *ci);
      goto error_exit;
    }
    circuit->constrained_to_true.push_back(*ci);
  }
  for(list<char*>::iterator ci = cp_false_gate_names.begin();
      ci != cp_false_gate_names.end();
      ci++) {
    Gate *gate = cp_named_gates[*ci];
    if(gate == 0) {
      fprintf(stderr, "gate '%s' assigned to false but not defined\n", *ci);
      goto error_exit;
    }
    circuit->constrained_to_false.push_back(*ci);
  }

  /*
   * Test acyclicity
   */
  if(!circuit->test_acyclicity())
    goto error_exit;

  return circuit;
 error_exit:
  if(circuit) delete circuit;
  return 0;
}


bool BC::test_acyclicity() {
  list <char*> cycle;
  bool acyclic = true;

  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++)
    (*gi)->temp = 0;

  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++) {
    if((*gi)->test_acyclicity(cycle) != 0) {
      acyclic = false;
      fprintf(stderr, "circuit has a cycle: ");
      for(list<char*>::iterator ci = cycle.begin(); ci != cycle.end();) {
	fprintf(stderr, "%s", *ci);
	ci++;
	if(ci != cycle.end())
	  fprintf(stderr, "->");
      }
      fprintf(stderr, "\n");
      break;
    }
    DEBUG_ASSERT(cycle.empty());
  }

  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++)
    (*gi)->temp = 0;

  return acyclic;
}

void BC::to_dot(FILE *fp)
{
  fprintf(fp, "digraph circuit {\n");
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++) {
    Gate *gate = *gi;
    fprintf(fp, "\"%u\" ", (unsigned int)gate);
    fprintf(fp, "[label=\"");

    if(gate->type == Gate::tEQUIV) {
      fprintf(fp, "EQUIV");
    }
    else if(gate->type == Gate::tOR) {
      fprintf(fp, "OR");
    }
    else if(gate->type == Gate::tAND) {
      fprintf(fp, "AND");
    }
    else if(gate->type == Gate::tEVEN) {
      fprintf(fp, "EVEN");
    }
    else if(gate->type == Gate::tODD) {
      fprintf(fp, "ODD");
    }
    else if(gate->type == Gate::tNOT) {
      fprintf(fp, "NOT");
    }
    else if(gate->type == Gate::tREF) {
      fprintf(fp, "REF");
    }
    else if(gate->type == Gate::tITE) {
      fprintf(fp, "ITE");
    }
    else if(gate->type == Gate::tTHRESHOLD) {
      fprintf(fp, "[%d,%d]", gate->tmin, gate->tmax);
    }
    else if(gate->type == Gate::tATLEAST) {
      fprintf(fp, ">=%d", gate->tmin);
    }
    else if(gate->type == Gate::tVAR) {
      DEBUG_ASSERT(gate->children == 0);
      DEBUG_ASSERT(gate->names.size() >= 1);
      fprintf(fp, "VAR"); //\\n%s", names.first());
    }
    else if(gate->type == Gate::tTRUE) {
      DEBUG_ASSERT(gate->children == 0);
      fprintf(fp, "T");
    }
    else if(gate->type == Gate::tFALSE) {
      DEBUG_ASSERT(gate->children == 0);
      fprintf(fp, "F");
    }
     else if(gate->type == Gate::tDELETED) {
       DEBUG_ASSERT(gate->children == 0);
      fprintf(fp, "!!!DELETED!!!");
    }
    else {
      internal_error("%s:%d: NYI %d", __FILE__, __LINE__, gate->type);
    }
    if(!gate->names.empty()) {
      fprintf(fp, "\\n");
      list<char*>::iterator ni = gate->names.begin();
      while(ni != gate->names.end()) {
	fprintf(fp, "%s", *ni);
	ni++;
	if(ni != gate->names.end()) fprintf(fp, ", ");
      }
    }
    fprintf(fp, "\"];\n");

    if(gate->type == Gate::tITE) {
      ChildAssoc *ca = gate->children;
      Gate *child = ca->child;
      ca = ca->next_child;
      fprintf(fp, "\"%u\" -> \"%u\" [label=\"if\"];\n",
	      (unsigned int)gate, (unsigned int)child);
      child = ca->child;
      ca = ca->next_child;
      fprintf(fp, "\"%u\" -> \"%u\" [label=\"then\"];\n",
	      (unsigned int)gate, (unsigned int)child);
      child = ca->child;
      ca = ca->next_child;
      fprintf(fp, "\"%u\" -> \"%u\" [label=\"else\"];\n",
	      (unsigned int)gate, (unsigned int)child);
      DEBUG_ASSERT(ca == 0);
    } else {
      for(ChildAssoc *ca = gate->children; ca; ca = ca->next_child) {
	fprintf(fp, "\"%u\" -> \"%u\";\n",
		(unsigned int)gate, (unsigned int)ca->child);
      }
    }
  }
  fprintf(fp, "}\n");
}


struct is_deleted : public unary_function<Gate*, bool> {
  bool operator()(Gate *gate) { return((gate->type == Gate::tDELETED)); }
};


void BC::share() {
  if(gates.empty()) return;
  
  GateHash *ht = new GateHash(gates.size() * 2);
  
  for(vector<Gate*>::iterator gi = gates.begin(); gi!=gates.end(); gi++)
    (*gi)->share(this, ht);
  
  gates.erase(remove_if(gates.begin(), gates.end(), is_deleted()),gates.end());
  if(verbose) {
    fprintf(verbstr, "circuit has %d gates after sharing\n", gates.size());
    fflush(verbstr); }
  
  delete ht;

  return;
}


void BC::simplify() {
  unsigned int gnum = 0;

  if(gates.empty()) return;
  
  while(gnum < gates.size()) {
    Gate *gate = gates[gnum++];
    gate->simplify(this);
  }
  gates.erase(remove_if(gates.begin(), gates.end(), is_deleted()),gates.end());
  if(verbose) {
    fprintf(verbstr, "circuit has %d gates after simplification\n",
	    gates.size());
    fflush(verbstr); }
}



void BC::to_cnf(FILE *fp) {
  unsigned int gnum = 0;
  extern bool do_simplifying;
  extern bool do_sharing;

#ifdef DEBUG
  {
    FILE *dotout = fopen("debug_phase1.dot", "w");
    to_dot(dotout);
    fclose(dotout);
  }
#endif

  /*
   * Share, simplify and normalize
   */
  while(true) {
    int changed_at_stage = 3;

    if(do_sharing) {
      changed = false;
      share();
      if(changed)
	changed_at_stage = 1;
      else if(changed_at_stage == 1)
	break;
    }
    if(do_simplifying) {
      changed = false;
      simplify();
      if(changed)
	changed_at_stage = 2;
      else if(changed_at_stage == 2)
	break;
    }
    /*
     * Normalize gates
     */
    changed = false;
    gnum = 0;
    while(gnum < gates.size()) {
      Gate *gate = gates[gnum++];
      gate->normalize(this);
    }
    gates.erase(remove_if(gates.begin(),gates.end(),is_deleted()),gates.end());
    if(verbose) {
      fprintf(verbstr, "circuit has %d gates after normalization\n",
	      gates.size());
      fflush(verbstr); }
    if(changed)
      changed_at_stage = 3;
    else if(changed_at_stage == 3)
      break;
  }

#ifdef DEBUG
  {
    FILE *dotout = fopen("debug_final.dot", "w");
    to_dot(dotout);
    fclose(dotout);
  }  
#endif

  /*
   * Number the gates in temp-fields
   */
  int gate_num = 1;
#ifdef NOTLESS_TRANSLATION
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++) {
    if((*gi)->type != Gate::tNOT)
      (*gi)->temp = gate_num++;
    else
      (*gi)->temp = INT_MAX;      
  }
#else
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++)
    (*gi)->temp = gate_num++;
#endif
  const int nof_variables = gate_num-1;

  /*
   * Print translation table
   */
#ifdef NOTLESS_TRANSLATION
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++) {
    Gate *gate = *gi;
    if(gate->names.empty())
      continue;
    for(list<char*>::iterator ni = gate->names.begin();
	ni != gate->names.end();
	ni++) {
      if(gate->type != Gate::tNOT)
	fprintf(fp, "c %s <-> %d\n", *ni, gate->temp);
      else
	fprintf(fp, "c %s <-> %d\n", *ni, -gate->children->child->temp);
    }
  }
#else
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++) {
    Gate *gate = *gi;
    if(gate->names.empty())
      continue;
    for(list<char*>::iterator ni = gate->names.begin();
	ni != gate->names.end();
	ni++) {
      fprintf(fp, "c %s <-> %d\n", *ni, gate->temp);
    }
  }
#endif

  /*
   * Count clauses
   */
  int nof_clauses = 0;
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++)
    nof_clauses += (*gi)->cnf_count_clauses();
  nof_clauses += constrained_to_true.size();
  nof_clauses += constrained_to_false.size();

  /*
   * Print problem line
   */
  fprintf(fp, "p cnf %d %d\n", nof_variables, nof_clauses);

  /*
   * Print clauses
   */
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++)
    (*gi)->cnf_print_clauses(fp);

  /*
   * Print constraints
   */
  hash_map<char *, Gate *, hash<char*>, eqstr> gate_names;
  for(vector<Gate*>::iterator gi = gates.begin(); gi != gates.end(); gi++) {
    Gate *gate = *gi;
    for(list<char*>::iterator ni = gate->names.begin();
	ni != gate->names.end();
	ni++) {
      DEBUG_ASSERT(gate_names[*ni] == 0);
      gate_names[*ni] = gate;
    }
  }
#ifdef NOTLESS_TRANSLATION
  for(list<char*>::iterator ni = constrained_to_true.begin();
      ni != constrained_to_true.end();
      ni++) {
    Gate *gate = gate_names[*ni];
    if(!gate)
      internal_error("%s:%d: SNH", __FILE__, __LINE__);
    if(gate->type != Gate::tNOT)
      fprintf(fp, "%d 0\n", gate->temp);
    else {
      gate = gate->children->child;
      DEBUG_ASSERT(gate->type != Gate::tNOT);
      fprintf(fp, "%d 0\n", -gate->temp);
    }
  }
  for(list<char*>::iterator ni = constrained_to_false.begin();
      ni != constrained_to_false.end();
      ni++) {
    Gate *gate = gate_names[*ni];
    if(!gate)
      internal_error("%s:%d: SNH", __FILE__, __LINE__);
    if(gate->type != Gate::tNOT)
      fprintf(fp, "%d 0\n", -gate->temp);
    else {
      gate = gate->children->child;
      DEBUG_ASSERT(gate->type != Gate::tNOT);
      fprintf(fp, "%d 0\n", gate->temp);
    }
  }
#else
  for(list<char*>::iterator ni = constrained_to_true.begin();
      ni != constrained_to_true.end();
      ni++) {
    Gate *gate = gate_names[*ni];
    if(!gate)
      internal_error("%s:%d: SNH", __FILE__, __LINE__);
    fprintf(fp, "%d 0\n", gate->temp);
  }
  for(list<char*>::iterator ni = constrained_to_false.begin();
      ni != constrained_to_false.end();
      ni++) {
    Gate *gate = gate_names[*ni];
    if(!gate)
      internal_error("%s:%d: SNH", __FILE__, __LINE__);
    fprintf(fp, "-%d 0\n", gate->temp);
  }
#endif
}

