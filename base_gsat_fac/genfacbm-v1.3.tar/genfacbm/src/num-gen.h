#ifndef PRIME_GEN_H
#define PRIME_GEN_H
#include <gmp.h>
typedef void (*num_gen_f)(int, mpz_t, char *);
void generate_prime(int, mpz_t, char *);
void generate_even(int length_in_bits, mpz_t even_number, char *);
void generate_random(int length_in_bits, mpz_t random_number, char *) ;
void generate_composite(int, mpz_t, char *);
#endif

