/*
 * (C) Tuomo Pyhala
 *
 */
#include <stdio.h>
#include "num-gen.h"
#include <gmp.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

struct gen_func_info {
  num_gen_f ngf;
  char *name;
};

main(int argc, char *argv[]) {
  mpz_t number;
  int i;
  int count = 1;
  int size = 16;
  int pad = 0;
  char *padstr;
  num_gen_f ngf = generate_prime;
  char *optstring = "c:w:t:pP:d";
  int descriptions = 0;
  char c;
  struct gen_func_info gfuncs[] = 
  {{generate_prime, "Prime generation"},
   {generate_even, "Even number generation"},
   {generate_random, "Random number generation"},
   {generate_composite, "Generate composite of two primes"},
   {NULL, NULL}};
  char *descstr;

  
  while((c = getopt(argc, argv, optstring)) != EOF) {
    switch(c) {
    case 'c':
      count = atoi(optarg);
      fprintf(stderr, "%d numbers will generated\n", count);
      break;
    case 'w':
      size = atoi(optarg);
      fprintf(stderr, "size %d bits\n", size);
      break;
    case 't':
      ngf = gfuncs[atoi(optarg)].ngf;
      fprintf(stderr, "%s selected\n", gfuncs[atoi(optarg)].name);
      break;
    case 'p':
      pad = size;
      fprintf(stderr, "pad %d bits\n", size);
      break;
    case 'P':
      pad = atoi(optarg);
      fprintf(stderr, "pad %d bits\n", pad);
      break;
    case 'd':
      descriptions = 1;
      break;
    default:
      fprintf(stderr, "Erraneous option\n");
      fprintf(stderr, "Functions available:\n");
      for(i=0; gfuncs[i].name != NULL; i++)
	fprintf(stderr, "-t %d: %s\n", i, gfuncs[i].name);
      return 1;
      break;
    }
  }
  
  padstr = malloc(sizeof(char)*(pad+1));
  for(i=0;i<pad; i++) {
    padstr[i] = '0';
  }
  padstr[pad] = 0;
  
  srand(time(NULL));
  descstr = malloc(sizeof(char)*(size*4+8));
  for(i=0; i<count; i++) {
    ngf(size, number, descstr);
    printf("%s", padstr);
    mpz_out_str(stdout, 2, number);
    if(descriptions)
      fprintf(stderr, " \t%s\n", descriptions ? descstr : "");
    //    else
      printf("\n");
    mpz_clear(number);
  }
}






