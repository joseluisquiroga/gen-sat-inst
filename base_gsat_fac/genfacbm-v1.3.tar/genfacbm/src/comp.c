/**
   (c) Tuomo Pyh�l� 2001

   Comment added: 2004-06-20
   This file contains a program to generate composite number
   with specified amount of factors.
   Usage:
   comp width sols amount base
   
   => width: the width of the numbers generated
   => sols: the number of solutions that the numbers should have
   => amount: Amount of solutions for the corresponding SAT problem
   => base: The base where numbers are presented (2 for binary)

**/

#include <stdio.h>
#include <stdlib.h>
#include <gmp.h>

typedef struct _mpz_list_t {
  struct _mpz_list_t *next;
  struct _mpz_list_t *prev;
  mpz_t number;
  int exp;
} mpz_list_t;

const int num_count = 256;


void print_list(mpz_list_t *l) {
 while(l != NULL) {
    mpz_out_str(stdout, 10, l->number);
    putchar('^');
    printf("%d", l->exp);
    putchar(' ');
    l = l->next;
  }
  putchar('\n');
}


mpz_list_t* remove_from_list(mpz_list_t *l) {
  mpz_list_t *retval;
  if(l->prev != NULL) {
    l->prev->next = l->next;
    if(l->next != NULL) {
      l->next->prev = l->prev;
      retval = l->next;
    }
    else {
      retval = l->prev;
    }
  }
  else {
    if(l->next != NULL) {
      l->next->prev = NULL;
      retval = l->next;
    }
    else {
      retval = NULL;
    }
  }
  free(l);
  return retval;
}

void append_to_list(mpz_list_t *eol, mpz_t n) {
  eol->next = malloc(sizeof(mpz_list_t));
  mpz_init_set(eol->next->number, n);
  eol->next->exp = 1;
  eol->next->next = NULL;
  eol->next->prev = eol;
}

mpz_list_t* append_mpz_to_eol(mpz_list_t *l, mpz_t n) {
  mpz_list_t *new_list;
  
  if(l == NULL) {
    new_list = malloc(sizeof(mpz_list_t));
    new_list->next = NULL;
    new_list->prev = NULL;
    mpz_init_set(new_list->number, n);
    new_list->exp = 1;
    return new_list;
  }
  
  for(new_list = l; new_list->next !=NULL; new_list = new_list->next);
  append_to_list(new_list, n);
  return l;
}

mpz_list_t* append_list_to_eol(mpz_list_t *l1, mpz_list_t *l2) {
  if(l1==NULL)
    return l2;
  if(l2==NULL)
    return l1;

  for(;l1->next!=NULL;l1=l1->next);
  for(;l2->prev!=NULL;l2=l2->prev);
  l1->next = l2;
  l2->prev = l1;
  for(;l2->prev!=NULL;l2=l2->prev);
  return l2;
}

int list_length(mpz_list_t *l) {
  int i;
  
  for(i=0; l != NULL; l = l->next) {
    i++;
  }
  return i;
}

mpz_list_t* factor_once(mpz_t num) 
{
  mpz_t trythis;
  mpz_t limit;
  mpz_t fac;
  mpz_t temp;
  mpz_list_t *l = NULL;
  mpz_init_set_ui(trythis, 2);
  mpz_init(limit);
  mpz_init(fac);
  mpz_init(temp);
  mpz_sqrt(limit, num);
  
  while(mpz_cmp(limit, trythis)>=0) {
    mpz_tdiv_r (fac, num, trythis);
    if(mpz_cmp_ui(fac, 0)==0) {
      mpz_tdiv_q(fac, num, trythis);
      l = append_mpz_to_eol(l, trythis);
      l = append_mpz_to_eol(l, fac);
      //      print_list(l);
      break;
    }
    mpz_add_ui(trythis, trythis, 1);
  }
  return l;
}

mpz_list_t* rewind_list(mpz_list_t *l) {
  if(l!= NULL) {
    for(;l->prev !=NULL; l = l->prev);
  }
  return l;
}

mpz_list_t* factor(mpz_t n) {
  mpz_list_t *l = NULL;
  mpz_list_t *factors = NULL;
  l = append_mpz_to_eol(l, n);
  
  do {
    //    print_list(l);
    factors = factor_once(l->number);
    if(list_length(factors) > 0) {
      l = remove_from_list(l);
      l = append_list_to_eol(l, factors);
      //      print_list(factors);
      //      print_list(l);
    }
    else {
      if(l->next != NULL) {
	l = l->next;
      }
      else {
	break;
      }
    }
  } while (1);
  return rewind_list(l);
}

mpz_list_t* swap(mpz_list_t *l) {
  mpz_list_t *cut;
  
  cut = l->next->next;
  
  l->next->next = l;
  l->next->prev = l->prev;
  if(l->prev != NULL)
    l->prev->next = l->next;
  l->prev=l->next;
  l->next=cut;
  
  if(cut != NULL)
    cut->prev = l;
  return l->prev;
}

mpz_list_t* bubble_sort_list(mpz_list_t *l) {
  int finalpass;
  
  do {
    finalpass = 1;
    for(l = rewind_list(l);l->next != NULL; l = l->next) {
      if(mpz_cmp(l->number, l->next->number)<0) {
	l = swap(l);
	finalpass = 0;
      }
    }
  } while (!finalpass);
  return rewind_list(l);
}

mpz_list_t* shrink_sorted_list(mpz_list_t *l) {
  while(l->next != NULL) {
    //    l->exp = 1;
    while(mpz_cmp(l->number, l->next->number)==0) {
      l->exp += 1;
      remove_from_list(l->next);
      if(l->next == NULL)
	break;
    }
    if(l->next != NULL)
      l = l->next;
  }
  return rewind_list(l);
}

int num_of_factor_pairs(mpz_list_t *l) {
  int pairs = 1 ;
  
  for(l = rewind_list(l); l != NULL; l = l->next)
    pairs *= (l->exp + 1);
  
  return pairs / 2 + (pairs%2);
}




int log2(int n) {
  int log=0;
  while(n>1) {
    n /= 2;
    log++;
  }
  if(n<1 && log>0)
    log--;
  return log;
}

void clear_list(mpz_list_t *l) {
  if(l != NULL) {
    l = rewind_list(l);
    while(l->next != NULL) {
      l = l->next;
      free(l->prev);
    }
    free(l);
  }
}

/**
   Generates next prime and adds it to the list.
   The temp parameter contains the new prime.
   @param primes contains the list
   
**/

mpz_list_t* continue_prime_list(mpz_list_t* primes) {
  mpz_t temp;

  for(;primes->next != NULL; primes = primes->next);
  mpz_init(temp);
  mpz_nextprime(temp, primes->number);
  primes = append_mpz_to_eol(primes, temp);
  return primes;
}
/**
   Generates list of all primes up to limit
 **/

mpz_list_t* gen_prime_list(mpz_t limit) {
  mpz_t temp;
  mpz_t rem;
  mpz_list_t *primes = NULL;

  mpz_init(rem);
  mpz_init_set_ui(temp, 2);
  primes = append_mpz_to_eol(primes, temp);
  mpz_add_ui(temp, temp, 1);
  while(mpz_cmp(limit,temp)>=0) {
    for(primes = rewind_list(primes);primes->next != NULL; primes = primes->next) {
      mpz_tdiv_r(rem, temp, primes->number);
      if(mpz_cmp_ui(rem, 0) == 0)
	break;
    }
    if(primes->next == NULL)
      primes = append_mpz_to_eol(primes, temp);
    mpz_add_ui(temp, temp, 2);
  }
  return rewind_list(primes);
}
/**
   Factors contains the factorization of the number. Each position
   in the array factors contains a number and the exponent for it. 
   This procedure returns the result of the multiplication of these 
   factors.
 **/
void multiply_array(mpz_t result, mpz_list_t * factors[], int factorcount) {
  int i;
  int j;

  mpz_set_ui(result, 1);
  
  //putchar('1');
  for(i=0; i<factorcount; i++) 
    for(j=0; j<factors[i]->exp; j++) {
       mpz_mul(result, result, factors[i]->number);
      //putchar('*');
      //mpz_out_str(stdout, 10, factors[i]->number);
    }
  //putchar('=');
  //mpz_out_str(stdout, 10, result);
  //  putchar('\n');
}


int gen_composite(int factors, int width, mpz_t result) {
  static int lastwidth = 0;
  static int lastfactors = 0;
  static int *last_returned = NULL;
  static mpz_list_t **returnset = NULL;
  int i,j, k;
  mpz_t remainder;
  mpz_t m;
  mpz_t temp;
  int factors_log2=log2(factors);
  static mpz_list_t *primes = NULL;
  int test_for_size = 0;

  /**
     Here we go if we have already been initialized.
     Successive calls return different numbers.
     returnset is sorted numerically all the time and contains
     distinct numbers.
   **/
  if(width == lastwidth && lastfactors == factors) {
    mpz_init_set_ui(temp, 0);
    mpz_set_ui(result,0);
    mpz_init_set_ui(m,0);
    mpz_setbit(temp, width-1);
    mpz_setbit(m, width);
    while(mpz_cmp(temp, result)>0 || mpz_cmp(m, result) < 0) {
      for(i=0; i<factors_log2-1; i++) {
	if(returnset[i]->next != returnset[i+1]) {
	  returnset[i] = returnset[i]->next;
	  break;
	}
      }
      /*
	In this branch we generate new numbers
      */
      if(i == factors_log2-1) {
	if(returnset[i]->next == NULL) {
	  primes = continue_prime_list(primes);
	}
	returnset[i] = returnset[i]->next;
	if(i!=0) {
	  returnset[0] = rewind_list(primes);
	  for(i=1; i<factors_log2-1; i++) {	
	    returnset[i] = returnset[i-1]->next;
	  }
	}
	test_for_size = 1;
      }
      
      multiply_array(result, returnset, factors_log2);
      if(test_for_size) {
	if(mpz_cmp(m, result)<0) {
	  mpz_set_ui(result,0);
	  return -1;
	  break;
	}
      }
    }
    mpz_clear(m);
    mpz_clear(temp);
    return 0;
  }
  /**
     Here we go when we are called for the first time
     First clean up, if we did some work for some other width
     Secondly, we generate list of primes starting from 2 and
     initialize returnset to contain successive items on this list.
   **/
  else {
    if(last_returned != NULL)
      free(last_returned);
    if(primes != NULL) {
      clear_list(primes);
      primes = NULL;
    }
    if(returnset != NULL) {
      free(returnset);
    }
    
    lastwidth = width;

    mpz_init_set_ui(m, 2);
    primes = gen_prime_list(m);
    returnset = malloc(sizeof(mpz_list_t*)*factors_log2);
    returnset[0] = primes;
    for(i=1; i<factors_log2; i++) {
      primes = continue_prime_list(primes);
      returnset[i] = returnset[i-1]->next;
    }
    lastwidth = width;
    lastfactors = factors;

    //    mpz_clear(temp);
    mpz_clear(m);

    // Recurse after initialization?
    return gen_composite(factors, width, result);
  }
  
}

int main(int argc, char *argv[]) {
  /*  mpz_t foo;
  mpz_t limit;
  mpz_list_t *l = NULL;
  mpz_init_set_ui(foo, 0);
  mpz_init_set_ui(limit, 0);
  int width = atoi(argv[1]);
  int num_of_pairs = atoi(argv[2]);
  int count = atoi(argv[3]);
  int i = 0;

  mpz_setbit(foo, width -1);
  mpz_setbit(limit, width);
  
  while(mpz_cmp(limit,foo) > 0 && i < count) {
    l = factor(foo);
    l = shrink_sorted_list(l);
    if(num_of_factor_pairs(l) >= num_of_pairs) {
      mpz_out_str(stdout, atoi(argv[4]), foo);
      putchar('\n');
      i++;
    }
    mpz_add_ui(foo, foo, 2);
    }*/
  int retval;
  mpz_t n;
  int i;
  char *pad = malloc(sizeof(char)*(atoi(argv[1])+1));
  
  for(i=0; i<atoi(argv[1]); i++) {
    pad[i] = '0';
  }
  pad[i] = 0;
  mpz_init(n);
  
  for(i=0; i<atoi(argv[3]); i++) {
    retval = gen_composite(atoi(argv[2]), atoi(argv[1]), n);
    if(retval == 0) {
      printf("%s", pad);
      mpz_out_str(stdout, atoi(argv[4]), n);
      putchar('\n');
    }
    else {
      break;
    }
  }
}


