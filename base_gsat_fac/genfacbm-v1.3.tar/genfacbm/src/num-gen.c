/*
 * (C) Tuomo Pyhala
 */
#include "num-gen.h"
#include <stdio.h>
#include <stdlib.h>
void get_random(int length_in_bits, mpz_t random_number);

void generate_prime(int length_in_bits, mpz_t prime, char *desc) {
  static int initialized = 0;
  static mpz_t last_prime;
  static mpz_t size_limit;
  static int last_length = 0;
  int i;
  
  if(!initialized) {
    mpz_init(last_prime);
    mpz_init(size_limit);
    initialized = 1;
  }
  mpz_init(prime);
  if(last_length == length_in_bits) {
    mpz_nextprime(prime, last_prime);
    mpz_set(last_prime, prime);
    if(mpz_cmp(size_limit, prime)<0) {
      last_length = 0;
      generate_prime(length_in_bits, prime, desc);
    }
  }
  else {
    mpz_set_ui(last_prime, 0);
    mpz_setbit(last_prime, length_in_bits-1);
    mpz_set_ui(size_limit, 0);
    mpz_setbit(size_limit, length_in_bits);
    mpz_nextprime(prime, last_prime);
    mpz_set(last_prime, prime);
    last_length =length_in_bits;
  }
}

void get_random(int length_in_bits, mpz_t random_number) 
{
  int i;
  mp_size_t length_in_limbs = length_in_bits/mp_bits_per_limb + ((length_in_bits%mp_bits_per_limb != 0) ? 1 : 0);

  mpz_random(random_number, length_in_limbs);  
  mpz_setbit(random_number, length_in_bits-1);
  
  for(i=length_in_bits; i<mp_bits_per_limb*length_in_limbs; i++) {
    mpz_clrbit(random_number, i);
  }
}

void generate_random(int length_in_bits, mpz_t random_number, char *desc) 
{
  mpz_init(random_number);
  get_random(length_in_bits, random_number);
}

void generate_even(int length_in_bits, mpz_t even_number, char *desc) 
{
  mpz_init(even_number);
  get_random(length_in_bits-1, even_number);
  mpz_mul_ui(even_number, even_number, 2);
}

void generate_composite(int length_in_bits, mpz_t prime_composite, char *desc) {
  static long int length = 0;
  static long int primesgenerated = 0;
  static long int compositesoutput = 0;
  static long int row = 0;
  static long int column = 0;
  static long int primearraysize = 0;
  static mpz_t *primes;
  mpz_t mp1,mp2,mp3,mp4;
  int i;
  char numstr1[length_in_bits+1];
  char numstr2[length_in_bits+1];

  if(length_in_bits != length) {
    if(primes != NULL) {
      for(i=0; i<primesgenerated; i++) {
	mpz_clear(primes[i]);
      }
      free(primes);
    }
    mpz_init_set_ui(mp1, 0);
    mpz_init_set_ui(mp2, 0);
    mpz_init(mp3);
    mpz_setbit(mp1, length_in_bits-1);
    mpz_setbit(mp2, length_in_bits);
    mpz_sqrt(mp1, mp1);
    mpz_sqrt(mp2, mp2);
    mpz_sub(mp3, mp2, mp1);
    mpz_div_ui(mp3, mp3, length_in_bits/2);
    primearraysize = mpz_get_ui(mp3);
    primes = malloc(sizeof(mpz_t)*primearraysize);
    mpz_init(primes[0]);
    mpz_nextprime(primes[0], mp1);
    primesgenerated = 1;
    compositesoutput = 0;

    length = length_in_bits;
    mpz_clear(mp1);
    mpz_clear(mp2);
    mpz_clear(mp3);
  }
  if(column<primesgenerated) {
    mpz_init(prime_composite);
    mpz_mul(prime_composite, primes[row], primes[column]);
    mpz_get_str (numstr1, 10, primes[row]);
    mpz_get_str (numstr2, 10, primes[column]);
    sprintf(desc, "%s*%s", numstr1, numstr2);
    column++;
  }
  else {
    if(primesgenerated<primearraysize) {
      mpz_init(primes[primesgenerated]);
      mpz_nextprime(primes[primesgenerated], primes[primesgenerated-1]);
      primesgenerated++;
      row++;
      column = 0;
      generate_composite(length_in_bits, prime_composite,desc);
    }
    else {
      compositesoutput = 0;
      column = 0;
      row = 0;
      generate_composite(length_in_bits, prime_composite, desc);
    }
  }
}





