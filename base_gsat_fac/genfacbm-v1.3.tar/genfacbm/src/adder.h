#ifndef ADDER_H
#define ADDER_H
void printadder(FILE *outfile, int width, char *inlines[], char *prefix);
#endif

