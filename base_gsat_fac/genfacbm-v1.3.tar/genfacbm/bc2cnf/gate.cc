/*
 Copyright (C) 2002 Tommi A. Junttila
 
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2
 as published by the Free Software Foundation.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <slist.h>
#include <algorithm>
#include "defs.hh"
#include "gate.hh"

ChildAssoc::ChildAssoc(Gate *f, Gate *c) :
  child(0), father(0),
  prev_child(0), next_child(0),
  prev_father(0), next_father(0)
{
  DEBUG_ASSERT(f);
  DEBUG_ASSERT(c);
  link_father(f);
  link_child(c);
}

ChildAssoc::~ChildAssoc() {
  unlink_father();
  unlink_child();
  /*
  DEBUG_ASSERT(father == 0);
  DEBUG_ASSERT(child == 0);
  DEBUG_ASSERT(prev_father == 0);
  DEBUG_ASSERT(next_father == 0);
  DEBUG_ASSERT(prev_child == 0);
  DEBUG_ASSERT(next_child == 0);
  */
}

void ChildAssoc::change_child(Gate *new_child) {
  DEBUG_ASSERT(new_child);
  unlink_child();
  link_child(new_child);
}

void ChildAssoc::change_father(Gate *new_father) {
  DEBUG_ASSERT(new_father);
  unlink_father();
  link_father(new_father);
}

void ChildAssoc::link_father(Gate *f) {
  DEBUG_ASSERT(father == 0);
  DEBUG_ASSERT(prev_child == 0);
  DEBUG_ASSERT(next_child == 0);
  father = f;
  next_child = father->children;
  if(next_child) {
    DEBUG_ASSERT(next_child->prev_child == 0);
    next_child->prev_child = this;
  }
  prev_child = 0;
  father->children = this;
}

void ChildAssoc::link_child(Gate *c) {
  DEBUG_ASSERT(child == 0);
  DEBUG_ASSERT(prev_father == 0);
  DEBUG_ASSERT(next_father == 0);
  child = c;
  next_father = child->fathers;
  if(next_father) {
    DEBUG_ASSERT(next_father->prev_father == 0);
    next_father->prev_father = this;
  }
  prev_father = 0;
  child->fathers = this;
}

void ChildAssoc::unlink_father() {
  if(next_child)
    next_child->prev_child = prev_child;

  if(prev_child)
    prev_child->next_child = next_child;
  else {
    DEBUG_ASSERT(father->children == this);
    father->children = next_child;
  }    
  father = 0;
  next_child = 0;
  prev_child = 0;
}

void ChildAssoc::unlink_child() {
  if(next_father)
    next_father->prev_father = prev_father;

  if(prev_father)
    prev_father->next_father = next_father;
  else {
    DEBUG_ASSERT(child->fathers == this);
    child->fathers = next_father;
  }
  child = 0;
  next_father = 0;
  prev_father = 0;
}

const char *Gate::typeNames[tNOFTYPES] = {"EQUIV",
                                          "OR",
                                          "AND",
                                          "EVEN",
                                          "ODD",
                                          "ITE",
                                          "NOT",
                                          "TRUE",
                                          "FALSE",
                                          "VAR",
                                          "THRESHOLD",
                                          "ATLEAST",
                                          "REF",
                                          "UNDEF",
					  "DELETED"};



void Gate::init() {
  temp = 0;
}

Gate::Gate(Type t) : 
  type(t), names(), children(0), fathers(0)
{
  init();
  //DEBUG_ASSERT(type == tTRUE || type == tFALSE);
}


Gate::Gate(Type t, char *name) : 
  type(t), names(), children(0), fathers(0)
{
  init();
  DEBUG_ASSERT(type == tUNDEF || type == tVAR || type == tREF);
  names.push_back(name);
}


Gate::Gate(Type t, Gate *child) : 
  type(t), names(), children(0), fathers(0)
{
  init();
  DEBUG_ASSERT(type == tNOT || type == tREF);
  DEBUG_ASSERT(child);
  add_child(child);
}


Gate::Gate(Type t, Gate *child1, Gate *child2) : 
  type(t), names(), children(0), fathers(0)
{
  init();
  DEBUG_ASSERT(type == tOR || type == tAND || type == tODD || type == tEVEN ||
               type == tEQUIV || type == tTHRESHOLD || type == tATLEAST);
  DEBUG_ASSERT(child1);
  DEBUG_ASSERT(child2);
  add_child(child2);
  add_child(child1);
}


Gate::Gate(Type t, Gate *if_child, Gate *then_child, Gate *else_child) : 
  type(t), names(), children(0), fathers(0)
{
  init();
  DEBUG_ASSERT(type == tITE);
  add_child(else_child);
  add_child(then_child);
  add_child(if_child);
}


Gate::Gate(Type t, list<Gate*> *childs) :
  type(t), names(), children(0), fathers(0)
{
  init();
  DEBUG_ASSERT(type == tOR || type == tAND || type == tODD || type == tEVEN ||
               type == tEQUIV || type == tTHRESHOLD || type == tATLEAST);
  for(list<Gate*>::reverse_iterator ci = childs->rbegin();
      ci != childs->rend();
      ci++) {
    add_child(*ci);
  }
  delete childs;

  DEBUG_ASSERT(children != 0);
  if(children->next_child == 0) {
    if(verbose)
      fprintf(verbstr, "An unary nary gate %s\n", typeNames[type]);
    /*
    if(type == tOR || type == tAND)
      type = tREF;
    else if(type == tTHRESHOLD || type == tATLEAST)
      ;
    else
      internal_error("unary %ss not yet handled", typeNames[type]);
    */
  }
}


Gate::~Gate() {
  while(children)
    delete children;
  while(fathers)
    delete fathers;
  /* free names */
  for(list<char*>::iterator ni = names.begin(); ni != names.end(); ni++) {
    free(*ni);
  }
}

class mypair {
public:
  mypair(unsigned int i1, unsigned int j1) : i(i1), j(j1) {}
  unsigned int i;
  unsigned int j;
};


void Gate::add_child(Gate *child) {
  new ChildAssoc(this, child);
}

void Gate::remove_all_children() {
  while(children)
    delete children;
}


#define CT_UNTEMP 0
#define CT_IN_STACK    1
#define CT_CYCLE_ENTRY 2
#define CT_TEMP   3

#define CTR_NO_CYCLE_FOUND 0
#define CTR_IN_CYCLE       1
#define CTR_CYCLE_FOUND    2

int Gate::test_acyclicity(list<char*> &cycle)
{
  if(!(temp >= 0 && temp <= 3)) internal_error("SNH");
  
  if(temp == CT_TEMP)
    return CTR_NO_CYCLE_FOUND;
  
  if(temp == CT_IN_STACK) {
    cycle.push_back(names.front());
    temp = CT_CYCLE_ENTRY;   // mark as the "root" of the cycle
    return CTR_IN_CYCLE;
  }
  
  temp = CT_IN_STACK;

  for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
    Gate *child = ca->child;
    int status = child->test_acyclicity(cycle);
     
    if(status == CTR_CYCLE_FOUND) {
      temp = CT_TEMP;
      return CTR_CYCLE_FOUND;
    }
    if(status == CTR_IN_CYCLE) {
      if(!names.empty()) {
	cycle.push_front(names.front());
        if(temp == CT_IN_STACK) {
          temp = CT_TEMP;
          return CTR_IN_CYCLE; }
        else {
          temp = CT_TEMP;
          return CTR_CYCLE_FOUND; }
      }
      temp = CT_TEMP;
      return CTR_IN_CYCLE;
    }
  }
  temp = CT_TEMP;
  return CTR_NO_CYCLE_FOUND;
}


void Gate::simplify(BC *bc) {
  if(type == tDELETED)
    return;

  /* limited cone of influence */
  if(!fathers && names.empty()) {
    remove_all_children();
    type = tDELETED;
    return;
  }


  switch(type) {
  case tFALSE:
  case tTRUE:
    DEBUG_ASSERT(!children);
    return;
  case tVAR:
    DEBUG_ASSERT(!children);
    return;
  case tREF: {
    /* remove */
    DEBUG_ASSERT(count_children() == 1);
    Gate *child = children->child;
    while(fathers)
      fathers->change_child(child);
    while(!names.empty()) {
      child->names.push_front(names.front());
      names.pop_front();
    }
    remove_all_children();
    type = tDELETED;
    bc->changed = true;
    return;
  }
  case tNOT: {
    DEBUG_ASSERT(count_children() == 1);
    Gate *child = children->child;
    if(child->type == tNOT) {
      /* g := ~~h  --> g := h */
      DEBUG_ASSERT(child->count_children() == 1);
      Gate *grand_child = child->children->child;
      while(fathers)
	fathers->change_child(grand_child);
      while(!names.empty()) {
	grand_child->names.push_front(names.front());
	names.pop_front();
      }
      remove_all_children();
      type = tDELETED;
      bc->changed = true;
      return;
    }
    if(child->type == tTRUE) {
      type = tFALSE;
      remove_all_children();
      bc->changed = true;
      return;
    }
    if(child->type == tFALSE) {
      type = tTRUE;
      remove_all_children();
      bc->changed = true;
      return;
    }
    return;
  }
  case tOR: {
    DEBUG_ASSERT(children);
    for(ChildAssoc *ca = children; ca; ) {
      Gate *child = ca->child;
      ChildAssoc *next_ca = ca->next_child;
      if(child->type == tTRUE) {
	type = tTRUE;
	remove_all_children();
	bc->changed = true;
	return;
      }
      if(child->type == tFALSE) {
	bc->changed = true;
	delete ca;
      }
      ca = next_ca;
    }
    if(!children) {
      type = tFALSE;     
      bc->changed = true;
      return;
    }
    if(count_children() == 1) {
      type = tREF;
      simplify(bc);
      bc->changed = true;
      return;
    }

    /* remove duplicate children */
    for(ChildAssoc *ca = children; ca; ca = ca->next_child)
      ca->child->temp = 0;
    for(ChildAssoc *ca = children; ca; ) {
      ChildAssoc *next_ca = ca->next_child;
      if(ca->child->temp != 0) {
	bc->changed = true;
	delete ca;
      }
      else
	ca->child->temp = 1;
      ca = next_ca;
    }
    for(ChildAssoc *ca = children; ca; ca = ca->next_child)
      ca->child->temp = 0;
    DEBUG_ASSERT(count_children() >= 1);

    if(count_children() == 1) {
      type = tREF;
      simplify(bc);
      bc->changed = true;
      return;
    }

    return;
  }
  case tAND: {
    DEBUG_ASSERT(children);
    for(ChildAssoc *ca = children; ca; ) {
      Gate *child = ca->child;
      ChildAssoc *next_ca = ca->next_child;
      if(child->type == tFALSE) {
	type = tFALSE;
	remove_all_children();
	bc->changed = true;
	return;
      }
      if(child->type == tTRUE) {
	bc->changed = true;
	delete ca;
      }
      ca = next_ca;
    }
    if(!children) {
      type = tTRUE;
      bc->changed = true;
      return;
    }
    if(children->next_child == 0) {
      type = tREF;
      simplify(bc);
      bc->changed = true;
      return;
    }

    /* remove duplicate children */
    for(ChildAssoc *ca = children; ca; ca = ca->next_child)
      ca->child->temp = 0;
    for(ChildAssoc *ca = children; ca; ) {
      ChildAssoc *next_ca = ca->next_child;
      if(ca->child->temp != 0) {
	bc->changed = true;
	delete ca;
      }
      else
	ca->child->temp = 1;
      ca = next_ca;
    }
    for(ChildAssoc *ca = children; ca; ca = ca->next_child)
      ca->child->temp = 0;
    DEBUG_ASSERT(count_children() >= 1);

    if(count_children() == 1) {
      type = tREF;
      simplify(bc);
      bc->changed = true;
      return;
    }

    return;
  }
  case tITE: {
    DEBUG_ASSERT(count_children() == 3);
    Gate *if_child = children->child;
    Gate *then_child = children->next_child->child;
    Gate *else_child = children->next_child->next_child->child;
    /* ITE(i,x,x) = REF(x) */
    if(then_child == else_child) {
      remove_all_children();
      type = tREF;
      add_child(if_child);
      simplify(bc);
      bc->changed = true;
      return;
    }
    /* ITE(T,t,e) = REF(t) */
    if(if_child->type == tTRUE) {
      remove_all_children();
      type = tREF;
      add_child(then_child);
      simplify(bc);
      bc->changed = true;
      return;
    }    
    /* ITE(F,t,e) = REF(e) */
    if(if_child->type == tFALSE) {
      remove_all_children();
      type = tREF;
      add_child(else_child);
      simplify(bc);
      bc->changed = true;
      return;
    }    
    /* ITE(i,T,e) = i | e */
    if(then_child->type == tTRUE) {
      remove_all_children();
      type = tOR;
      add_child(else_child);
      add_child(if_child);
      simplify(bc);
      bc->changed = true;
      return;
    }    
    /* ITE(i,F,e) = ~i & e */
    if(then_child->type == tFALSE) {
      Gate *new_not = new Gate(tNOT, if_child);
      bc->gates.push_back(new_not);
      remove_all_children();
      type = tAND;
      add_child(else_child);
      add_child(new_not);
      simplify(bc);
      bc->changed = true;
      return;
    }    
    /* ITE(i,t,T) = ~i | t */
    if(else_child->type == tTRUE) {
      Gate *new_not = new Gate(tNOT, if_child);
      bc->gates.push_back(new_not);
      remove_all_children();
      type = tOR;
      add_child(then_child);
      add_child(new_not);
      simplify(bc);
      bc->changed = true;
      return;
    }    
    /* ITE(i,t,F) = i & t */
    if(else_child->type == tFALSE) {
      remove_all_children();
      type = tAND;
      add_child(then_child);
      add_child(if_child);
      simplify(bc);
      bc->changed = true;
      return;
    }    
    return;
  }
  case tEQUIV: {
    DEBUG_ASSERT(count_children() >= 1);
    if(count_children() == 1) {
      type = tTRUE;
      remove_all_children();
      bc->changed = true;
      return;
    }
    DEBUG_ASSERT(count_children() >= 2);
    for(ChildAssoc *ca = children; ca; ) {
      Gate *child = ca->child;
      if(child->type == tTRUE) {
	/* g := EQUIV(T,g1,...,gn) --> g := AND(g1,...,gn) */
	delete ca;
	type = tAND;
	bc->changed = true;
	simplify(bc);
	return;
      }
      if(child->type == tFALSE) {
	/* g := EQUIV(F,g1,...,gn) --> g := AND(~g1,...,~gn) */
	delete ca;
	type = tAND;
	list<Gate*> childs;
	while(children) {
	  childs.push_front(children->child);
	  delete children;
	}
	while(!childs.empty()) {
	  Gate *new_not = new Gate(tNOT, childs.front());
	  childs.pop_front();
	  bc->gates.push_back(new_not);
	  add_child(new_not);
	}
	bc->changed = true;
	simplify(bc);
	return;
      }
      ca = ca->next_child;
    }
    return;
  }
  case tODD:
  case tEVEN: {
    DEBUG_ASSERT(count_children() >= 1);
    for(ChildAssoc *ca = children; ca; ) {
      Gate *child = ca->child;
      ChildAssoc *next_ca = ca->next_child;
      if(child->type == tFALSE) {
	bc->changed = true;
	delete ca;
      }
      if(child->type == tTRUE) {
	if(type == tEVEN) type = tODD;
	else if(type == tODD) type = tEVEN;
	else internal_error("%s:%d: SNH", __FILE__, __LINE__);
	bc->changed = true;
	delete ca;
      }
      ca = next_ca;
    }
    if(count_children() == 0) {
      if(type == tEVEN) type = tTRUE;
      else if(type == tODD) type = tFALSE;
      else internal_error("%s:%d: SNH", __FILE__, __LINE__);
      bc->changed = true;
      return;
    }
    if(count_children() == 1) {
      if(type == tEVEN) type = tNOT;
      else if(type == tODD) type = tREF;
      else internal_error("%s:%d: SNH", __FILE__, __LINE__);
      simplify(bc);
      bc->changed = true;
      return;
    }
    return;
  }
  default:
    ;
  }
}

void Gate::normalize(BC * const bc) {
  if(type == tDELETED)
    return;

  if(type != tITE)
    sort_children();

  switch(type) {
  case tFALSE:
  case tTRUE:
  case tVAR:
    DEBUG_ASSERT(count_children() == 0);
    return;
#ifdef NOTLESS_TRANSLATION
  case tREF: {
    /* remove */
    DEBUG_ASSERT(count_children() == 1);
    Gate *child = children->child;
    while(fathers)
      fathers->change_child(child);
    while(!names.empty()) {
      child->names.push_front(names.front());
      names.pop_front();
    }
    remove_all_children();
    type = tDELETED;
    bc->changed = true;
    return;
  }
  case tNOT: {
    DEBUG_ASSERT(count_children() == 1);
    Gate *child = children->child;
    if(child->type == tNOT) {
      /* g := ~~h  --> g := h */
      DEBUG_ASSERT(child->count_children() == 1);
      Gate *grand_child = child->children->child;
      while(fathers)
	fathers->change_child(grand_child);
      while(!names.empty()) {
	grand_child->names.push_front(names.front());
	names.pop_front();
      }
      remove_all_children();
      type = tDELETED;
      bc->changed = true;
      return;
    }
    return;
  }
#else
  case tNOT:
  case tREF:
    DEBUG_ASSERT(count_children() == 1);
    return;
#endif
  case tOR:
  case tAND:
    DEBUG_ASSERT(count_children() >= 1);
    if(count_children() == 1) {
      type = Gate::tREF;
      normalize(bc);
      bc->changed = true;
    }
    return;
  case tEQUIV: {
    DEBUG_ASSERT(count_children() >= 1);
    if(count_children() == 1) {
      type = Gate::tTRUE;
      remove_all_children();
      bc->changed = true;
      return;
    }
    if(count_children() == 2)
      return;

    DEBUG_ASSERT(count_children() >= 3);

    /* g:=EQUIV(c1,...,cn) --> g:= AND(c1,...,cn) | AND(~c1,...,~cn) */
    Gate *new_child1 = new Gate(Gate::tAND);
    for(ChildAssoc *ca = children; ca; ca = ca->next_child)
      new_child1->add_child(ca->child);
    bc->gates.push_back(new_child1);
    
    Gate *new_child2 = new Gate(Gate::tAND);
    bc->gates.push_back(new_child2);
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      Gate *not_child = new Gate(Gate::tNOT, ca->child);
      bc->gates.push_back(not_child);
      new_child2->add_child(not_child);
    }

    type = Gate::tOR;
    remove_all_children();
    add_child(new_child1);
    add_child(new_child2);
    bc->changed = true;
    return;
  }
  case Gate::tITE: {
    DEBUG_ASSERT(count_children() == 3);
#ifdef EXPLODE_ITES
    /* ITE(i,t,e) <=> (i & t) | (~i & e) */
    Gate *if_child = children->child;
    Gate *then_child = children->next_child->child;
    Gate *else_child = children->next_child->next_child->child;
    remove_all_children();
    type = tOR;
    Gate *new_child1 = new Gate(tAND, if_child, then_child);
    bc->gates.push_back(new_child1);
    add_child(new_child1);
    Gate *new_not = new Gate(tNOT, if_child);
    bc->gates.push_back(new_not);
    Gate *new_child2 = new Gate(tAND, new_not, else_child);
    bc->gates.push_back(new_child2);
    add_child(new_child2);
    bc->changed = true;
#endif
    return;
  }
  case Gate::tTHRESHOLD: {
    /* Threshold gates must be eliminated! */
    bc->changed = true;
    
    DEBUG_ASSERT(count_children() >= 1);
    if(tmin > count_children()) {
      /* trivially false */
      type = Gate::tFALSE;
      remove_all_children();
      bc->changed = true;
      return;
    }
    if(tmax > count_children()) tmax = count_children();
    if(tmax < tmin) {
      /* trivially false */
      type = Gate::tFALSE;
      remove_all_children();
      bc->changed = true;
      return;      
    }
    DEBUG_ASSERT(tmin <= count_children());
    DEBUG_ASSERT(tmin <= tmax);
    DEBUG_ASSERT(tmax <= count_children());

    if(count_children() == 1) {
      if(tmin == 0 && tmax == 1) {
	/* trivially true */
	type = Gate::tTRUE;
	remove_all_children();
	return;      
      }
      if(tmin == 0 && tmax == 0) {
	/* trivially true */
	type = Gate::tNOT;
	normalize(bc);
	return;      
      }
      if(tmin == 1 && tmax == 1) {
	/* trivially true */
	type = Gate::tREF;
	normalize(bc);
	return;      
      }
      internal_error("SNH");
    }

#ifdef THRESHOLD_ITE_EXPANSION
    if(tmin == 0 && tmax == count_children()) {
      /* trivially true */
      type = Gate::tTRUE;
      remove_all_children();
      return;      
    }

    Gate *new_child1 = new Gate(tTHRESHOLD);
    bc->gates.push_back(new_child1);
    new_child1->tmin = (tmin==0)?0:tmin-1;
    new_child1->tmax = (tmax==0)?0:tmax-1;
    for(ChildAssoc *ca = children->next_child; ca; ca = ca->next_child)
      new_child1->add_child(ca->child);

    Gate *new_child2 = new Gate(tTHRESHOLD);
    bc->gates.push_back(new_child2);
    new_child2->tmin = tmin;
    new_child2->tmax = tmax;
    for(ChildAssoc *ca = children->next_child; ca; ca = ca->next_child)
      new_child2->add_child(ca->child);

    Gate *first_child = children->child;
    remove_all_children();
    type = tITE;
    add_child(new_child2);
    add_child(new_child1);
    add_child(first_child);    
    normalize(bc);
    return;
#else
    if(tmin == 0) {
      if(tmax == count_children()) {
	/* [0,n](g1,...,gn) trivially true */
	type = Gate::tTRUE;
	remove_all_children();
	return;
      }
      /* [0,k](g1,...,gn) = ~(>= k+1)(g1,...,gn) */
      Gate *new_child = new Gate(Gate::tATLEAST);
      bc->gates.push_back(new_child);
      new_child->tmin = tmax + 1;
      while(children)
	children->change_father(new_child);
      add_child(new_child);
      type = Gate::tNOT;
      return;
    }

    if(tmax == count_children()) {
      DEBUG_ASSERT(tmin > 0);
      /* [l,n](g1,...gn) = (>= l)(g1,...,gn) */
      type = tATLEAST;
      normalize(bc);
      return;
    }

    DEBUG_ASSERT(tmin > 0);
    DEBUG_ASSERT(tmax < count_children());
    DEBUG_ASSERT(tmin <= tmax);

    {
      /* [l,u](g1,...,gn) =  (>= l)(g1,...,gn) & ~(>= u+1)(g1,...,gn) */
      Gate *new_child1 = new Gate(tATLEAST);
      bc->gates.push_back(new_child1);
      new_child1->tmin = tmin;
      for(ChildAssoc *ca = children; ca; ca = ca->next_child)
	new_child1->add_child(ca->child);

      Gate *new_child2 = new Gate(tATLEAST);
      bc->gates.push_back(new_child2);
      new_child2->tmin = tmax+1;
      while(children)
	children->change_father(new_child2);
      Gate *new_child3 = new Gate(tNOT, new_child2);
      bc->gates.push_back(new_child3);

      add_child(new_child1);
      add_child(new_child3);
      type = Gate::tAND;
    }
#endif
    return;
  }
  case tATLEAST: {
    /* Internal ATLEAST-gates must be eliminated! */
    bc->changed = true;
    DEBUG_ASSERT(count_children() >= 1);
    if(tmin == 0) {
      /* trivially true */
      type = tTRUE;
      remove_all_children();
      return;
    }
    if(tmin > count_children()) {
      /* trivially false */
      type = tFALSE;
      remove_all_children();
      return;
    }
    if(tmin == count_children()) {
      type = tAND;
      normalize(bc);
      return;
    }
    DEBUG_ASSERT(count_children() > 1);

#define POLYNOMIAL_ATLEAST_REWRITING
#ifdef POLYNOMIAL_ATLEAST_REWRITING
    vector<Gate*> childs;
    for(ChildAssoc *ca = children; ca; ca = ca->next_child)
      childs.push_back(ca->child);

    Gate ***array = (Gate***)malloc(sizeof(Gate**) * (tmin + 1));
    for(unsigned int i = 0; i <= tmin; i++) {
      array[i] = (Gate**)malloc(sizeof(Gate*) * (childs.size()+1));
      for(unsigned int j = 0; j <= childs.size(); j++) {
	array[i][j] = new Gate(tUNDEF);
	array[i][j]->temp = 0;
      }
    }

    delete array[tmin][childs.size()];
    array[tmin][childs.size()] = this;
    remove_all_children();
    array[tmin][childs.size()]->temp = 0;

    slist<mypair> todo;
    todo.push_front(mypair(tmin,childs.size()));
    while(!todo.empty()) {
      mypair pair = todo.front();
      todo.pop_front();
      unsigned int i = pair.i;
      unsigned int j = pair.j;
      DEBUG_ASSERT(i > 0);
      DEBUG_ASSERT(i <= tmin);
      DEBUG_ASSERT(j <= childs.size());
      DEBUG_ASSERT(j >= i);
      if(array[i][j]->temp != 0)
	continue;
      array[i][j]->temp = 1;
      if(array[i][j] != this)
	bc->gates.push_back(array[i][j]);
      if(i == j) {
	if(i == 1) {
	  array[i][j]->type = tREF;
	  array[i][j]->remove_all_children();
	  array[i][j]->add_child(childs[j-1]);
	  continue;
	}
	array[i][j]->type = tAND;
	array[i][j]->remove_all_children();
	array[i][j]->add_child(childs[j-1]);
	array[i][j]->add_child(array[i-1][j-1]);
	todo.push_front(mypair(i-1,j-1));
	continue;
      }
      if(i == 1) {
	array[i][j]->type = tOR;
	array[i][j]->remove_all_children();
	array[i][j]->add_child(childs[j-1]);
	array[i][j]->add_child(array[i][j-1]);
	todo.push_front(mypair(i,j-1));
	continue;
      }
      Gate *new_gate = new Gate(tAND,childs[j-1],array[i-1][j-1]);
      todo.push_front(mypair(i-1,j-1));
      bc->gates.push_back(new_gate);
      array[i][j]->type = tOR;
      array[i][j]->remove_all_children();
      array[i][j]->add_child(new_gate);
      array[i][j]->add_child(array[i][j-1]);
      todo.push_front(mypair(i,j-1));
    }

    for(unsigned int i = 0; i <= tmin; i++) {
      for(unsigned int j = 0; j <= childs.size(); j++) {
	if(array[i][j]->type == tUNDEF) {
	  DEBUG_ASSERT(array[i][j]->temp == 0);
	  delete array[i][j];
	} else {
	  DEBUG_ASSERT(array[i][j]->temp != 0);
	}
      }
      free(array[i]);
    }
    free(array);

    return;
#else /* simple exponential rewriting of ATLEASTs */
    if(tmin == 1) {
      Gate *child1 = children.front();
      children.pop_front();
      Gate *new_child2 = new Gate(tATLEAST);
      bc->gates.push_back(new_child2);
      new_child2->children = children;
      new_child2->tmin = tmin;
      children.clear();
      children.push_back(child1);
      children.push_back(new_child2);
      type = tOR;
      return;
    }

    Gate *new_child1 = new Gate(tAND);
    bc->gates.push_back(new_child1);
    new_child1->children.push_back(children.front());

    Gate *new_child2 = new Gate(tATLEAST);
    bc->gates.push_back(new_child2);
    new_child2->children = children;
    new_child2->children.pop_front();
    new_child2->tmin = tmin - 1;
    new_child1->children.push_back(new_child2);

    Gate *new_child3 = new Gate(tATLEAST);
    bc->gates.push_back(new_child3);
    new_child3->children = children;
    new_child3->children.pop_front();
    new_child3->tmin = tmin;
    
    type = tOR;
    children.clear();
    children.push_back(new_child1);
    children.push_back(new_child3);
    return;
#endif
  }
  case tEVEN: {
    DEBUG_ASSERT(count_children() >= 1);
    if(count_children() == 1) {
      type = Gate::tNOT;
      normalize(bc);
      bc->changed = true;
      return;
    }
    if(count_children() == 2)
      return;
    DEBUG_ASSERT(count_children() >= 3);
    /* EVEN(g1,...,gn) = NOT(ODD(g1,...,gn)) */
    Gate *new_odd = new Gate(tODD);
    bc->gates.push_back(new_odd);
    while(children) {
      new_odd->add_child(children->child);
      delete children;
    }
    type = tNOT;
    add_child(new_odd);
    bc->changed = true;
    return;
  }
  case tODD: {
    DEBUG_ASSERT(count_children() >= 1);
    if(count_children() == 1) {
      type = Gate::tREF;
      normalize(bc);
      bc->changed = true;
      return;
    }
    if(count_children() == 2)
      return;
    DEBUG_ASSERT(count_children() >= 3);
    /* ODD(g1,...,gn) = ODD(g1,ODD(g2,...,gn)) */
    Gate *new_odd = new Gate(tODD);
    bc->gates.push_back(new_odd);
    Gate *child1 = children->child;
    delete children;
    while(children) {
      new_odd->add_child(children->child);
      delete children;
    }
    add_child(new_odd);
    add_child(child1);
    bc->changed = true;
    return;
  }

  case tDELETED:
    DEBUG_ASSERT(children == 0);
    DEBUG_ASSERT(fathers == 0);
    return;
  default:
    ;
    internal_error("%s:%d: %s NYI", __FILE__,__LINE__,typeNames[type]);
  }

  internal_error("%s:%d: %s SNH", __FILE__,__LINE__);
  return;
}

unsigned int Gate::hash_value() {
  unsigned int h;
  switch(type) {
  case tTRUE:
    h = 3; break;
  case tFALSE:
    h = 7; break;
  case tVAR:
    h = 13;
    DEBUG_ASSERT(!names.empty());
    {
      char *name = (char*)names.front();
      unsigned int i;
      h = h * strlen(name);
      for(i = 0; i < strlen(name); i++)
        h = (h << 2) + (unsigned int)name[i];
    }
    return h;
    break;
  case tEQUIV:
    h = 17; break;
  case tOR:
    h = 23; break;
  case tAND:
    h = 31; break;
  case tTHRESHOLD:
    h = 37; break;
  case tNOT:
    h = 43; break;
  case tREF:
    h = 51; break;
  case tEVEN:
    h = 59; break;
  case tODD:
    h = 61; break;
  case tITE:
    h = 67; break;
  case tATLEAST:
    h = 71; break;
  default:
    internal_error("%s,%d: NYI %s",__FILE__,__LINE__, typeNames[type]);
  }
  for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
    Gate *child = ca->child;
    h = h * ((unsigned int)child + 77) + 79;
  }
  return h;
}


int Gate::comp(const Gate *gate2) const {
  if(type < gate2->type)
    return -1;
  if(type > gate2->type)
    return 1;
  if(type == tFALSE || type == tTRUE)
    return 0;
  if(type == tVAR) {
    DEBUG_ASSERT(!names.empty());
    DEBUG_ASSERT(!gate2->names.empty());
    return strcmp(names.front(), gate2->names.front());
  }

  DEBUG_ASSERT(children && gate2->children);

  ChildAssoc *ca1 = children;
  ChildAssoc *ca2 = gate2->children;
  while(ca1 && ca2) {
    if(ca1->child < ca2->child)
      return -1;
    if(ca1->child > ca2->child)
      return 1;
    ca1 = ca1->next_child;
    ca2 = ca2->next_child;
  }
  if(ca1)
    return 1;
  if(ca2)
    return -1;
  return 0;
}


void Gate::share(BC *bc, GateHash *ht) {
  if(type == tDELETED)
    return;
  if(type == tVAR)
    return;
  if(ht->is_in(this))
    return;

  for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
    Gate *child = ca->child;
    child->share(bc, ht);
  }

  //
  // Sort the child pointers expect for
  // ITE which is the only non-commutative function
  //
  if(type != tITE) 
    sort_children();

  Gate *existing_gate = ht->test_and_set(this);
  if(existing_gate != this) {
    while(!names.empty()) {
      existing_gate->names.push_back(names.front());
      names.pop_front();
    }
    remove_all_children();
    while(fathers)
      fathers->change_child(existing_gate);
    type = tDELETED;
    bc->changed = true;
  }
  return;
}




void Gate::sort_children() {
  DEBUG_ASSERT(type != tITE);

  if(!children)
    return;
  ChildAssoc *ca = children->next_child;
  while(ca) {
    ChildAssoc *ca2 = ca;
    Gate *child = ca->child;
    ca2->unlink_child();
    while(ca2 != children && ca2->prev_child->child > child) {
      ca2->link_child(ca2->prev_child->child);
      ca2 = ca2->prev_child;
      ca2->unlink_child();
    }
    ca2->link_child(child);
    ca = ca->next_child;
  }
}

unsigned int Gate::count_children() {
  unsigned int i = 0;
  for(ChildAssoc *ca = children; ca; ca = ca->next_child)
    i++;
  return i;
}


int Gate::cnf_count_clauses() {
  switch(type) {
  case tFALSE:
  case tTRUE:
    DEBUG_ASSERT(children == 0);
    return 1;
  case tVAR:
    DEBUG_ASSERT(children == 0);
    return 0;
#ifdef NOTLESS_TRANSLATION
  case tREF:
    internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
  case tNOT:
    DEBUG_ASSERT(count_children() == 1);
    DEBUG_ASSERT(children->child->type != tNOT);
    return 0;
#else
  case tREF:
  case tNOT:
    DEBUG_ASSERT(children);
    DEBUG_ASSERT(children->next_child == 0);
    return 2;
#endif
  case tOR:
  case tAND:
    DEBUG_ASSERT(children);
    DEBUG_ASSERT(children->next_child);
    return count_children() + 1;
  case tEQUIV:
  case tEVEN:
  case tODD:
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    return 4;
  case tITE:
    DEBUG_ASSERT(count_children() == 3);
    return 4;
  default:
    internal_error("%s:%d: %s NYI", __FILE__,__LINE__,typeNames[type]);
  }
  internal_error("%s:%d: %s SNH", __FILE__,__LINE__);
  return 0;
}

void Gate::cnf_print_clauses(FILE *fp) {
  switch(type) {
  case tFALSE: {
    DEBUG_ASSERT(children == 0);
    fprintf(fp, "-%d 0\n", temp);
    return;
  }
  case tTRUE: {
    DEBUG_ASSERT(children == 0);
    fprintf(fp, "%d 0\n", temp);
    return;
  }
  case tVAR: {
    DEBUG_ASSERT(children == 0);
    return;
  }
#ifdef NOTLESS_TRANSLATION
  /* Translation without REFs and NOTs */
  case tREF:
    internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
  case tNOT:
    DEBUG_ASSERT(count_children() == 1);
    DEBUG_ASSERT(children->child->type != tNOT);
    return;
  case tOR: {
    DEBUG_ASSERT(count_children() >= 1);
    /* g -> c1 | ... | cn */
    fprintf(fp, "%d ", -temp);
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      if(ca->child->type != tNOT)
	fprintf(fp, "%d ", ca->child->temp);
      else
	fprintf(fp, "%d ", -ca->child->children->child->temp);
    }
    fprintf(fp, "0\n");
    
    /* !g -> !ci */
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      if(ca->child->type != tNOT)
	fprintf(fp, "%d %d 0\n", temp, -ca->child->temp);
      else
	fprintf(fp, "%d %d 0\n", temp, ca->child->children->child->temp);
    }
    return;
  }
  case tAND: {
    DEBUG_ASSERT(children);
    /* !g -> !c1 | ... | !cn */
    fprintf(fp, "%d ", temp);
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      if(ca->child->type != tNOT)
	fprintf(fp, "%d ", -ca->child->temp);
      else
	fprintf(fp, "%d ", ca->child->children->child->temp);
    }
    fprintf(fp, "0\n");

    /* g -> ci */
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      if(ca->child->type != tNOT)
	fprintf(fp, "%d %d 0\n", -temp, ca->child->temp);
      else
	fprintf(fp, "%d %d 0\n", -temp, -ca->child->children->child->temp);
    }
    return;
  }
  case tEQUIV: {
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    ChildAssoc *ca = children;
    Gate *child1 = ca->child; ca = ca->next_child;
    Gate *child2 = ca->child; ca = ca->next_child;
    int c1lit, c2lit;
    if(child1->type != tNOT) c1lit = child1->temp;
    else c1lit = -child1->children->child->temp;
    if(child2->type != tNOT) c2lit = child2->temp;
    else c2lit = -child2->children->child->temp;
    DEBUG_ASSERT(ca == 0);
    /* g := c1 == c2 */
    /* g -> (c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", -temp, -c1lit, c2lit);
    /* g -> (~c1 -> ~c2) */
    fprintf(fp, "%d %d %d 0\n", -temp, c1lit, -c2lit);
    /* ~g -> (c1 -> ~c2) */
    fprintf(fp, "%d %d %d 0\n", temp, -c1lit, -c2lit);
    /* ~g -> (~c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", temp, c1lit, c2lit);
    return;
  }
  case tEVEN: {
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    ChildAssoc *ca = children;
    Gate *child1 = ca->child; ca = ca->next_child;
    Gate *child2 = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    int c1lit, c2lit;
    if(child1->type != tNOT) c1lit = child1->temp;
    else c1lit = -child1->children->child->temp;
    if(child2->type != tNOT) c2lit = child2->temp;
    else c2lit = -child2->children->child->temp;
    /* g := c1 == c2 */
    /* g -> (c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", -temp, -c1lit, c2lit);
    /* g -> (~c1 -> ~c2) */
    fprintf(fp, "%d %d %d 0\n", -temp, c1lit, -c2lit);
    /* ~g -> (c1 -> ~c2) */
    fprintf(fp, "%d %d %d 0\n", temp, -c1lit, -c2lit);
    /* ~g -> (~c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", temp, c1lit, c2lit);
    return;
  }
  case tODD: {
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    ChildAssoc *ca = children;
    Gate *child1 = ca->child; ca = ca->next_child;
    Gate *child2 = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    int c1lit, c2lit;
    if(child1->type != tNOT) c1lit = child1->temp;
    else c1lit = -child1->children->child->temp;
    if(child2->type != tNOT) c2lit = child2->temp;
    else c2lit = -child2->children->child->temp;
    /* g := c1 ^ c2 */
    /* g -> (c1 -> ~c2) */
    fprintf(fp, "%d %d %d 0\n", -temp, -c1lit, -c2lit);
    /* g -> (~c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", -temp, c1lit, c2lit);
    /* ~g -> (c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", temp, -c1lit, c2lit);
    /* ~g -> (~c1 -> ~c2) */
    fprintf(fp, "%d %d %d 0\n", temp, c1lit, -c2lit);
    return;
  }
  case tITE: {
    DEBUG_ASSERT(children);
    DEBUG_ASSERT(children->next_child);
    DEBUG_ASSERT(children->next_child->next_child);
    DEBUG_ASSERT(children->next_child->next_child->next_child == 0);
    ChildAssoc *ca = children;
    Gate *if_child = ca->child; ca = ca->next_child;
    Gate *then_child = ca->child; ca = ca->next_child;
    Gate *else_child = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    int if_lit, then_lit, else_lit;
    if(if_child->type != tNOT) if_lit = if_child->temp;
    else if_lit = -if_child->children->child->temp;
    if(then_child->type != tNOT) then_lit = then_child->temp;
    else then_lit = -then_child->children->child->temp;
    if(else_child->type != tNOT) else_lit = else_child->temp;
    else else_lit = -else_child->children->child->temp;
 
    /* g := ITE(i,t,e) */
    /* g -> (i -> t) */
    fprintf(fp, "%d %d %d 0\n", -temp, -if_lit, then_lit);
    /* g -> (~i -> e) */
    fprintf(fp, "%d %d %d 0\n", -temp, if_lit, else_lit);
    /* ~g -> (i -> ~t) */
    fprintf(fp, "%d %d %d 0\n", temp, -if_lit, -then_lit);
    /* ~g -> (~i -> ~e) */
    fprintf(fp, "%d %d %d 0\n", temp, if_lit, -else_lit);
    return;
  }
#else
  /* Straightforward translation */
  case tREF: {
    DEBUG_ASSERT(children);
    DEBUG_ASSERT(children->next_child == 0);
    Gate *child = children->child;
    fprintf(fp, "%d -%d 0\n", temp, child->temp);
    fprintf(fp, "-%d %d 0\n", temp, child->temp);    
    return;
  }
  case tNOT: {
    DEBUG_ASSERT(children);
    DEBUG_ASSERT(children->next_child == 0);
    Gate *child = children->child;
    fprintf(fp, "%d %d 0\n", temp, child->temp);
    fprintf(fp, "-%d -%d 0\n", temp, child->temp);
    return;
  }
  case tOR: {
    DEBUG_ASSERT(children);
    /* g -> c1 | ... | cn */
    fprintf(fp, "-%d ", temp);
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      fprintf(fp, "%d ", ca->child->temp);
    }
    fprintf(fp, "0\n");

    /* !g -> !ci */
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      fprintf(fp, "%d -%d 0\n", temp, ca->child->temp);
    }
    return;
  }
  case tAND: {
    DEBUG_ASSERT(children);
    /* !g -> !c1 | ... | !cn */
    fprintf(fp, "%d ", temp);
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      fprintf(fp, "-%d ", ca->child->temp);
    }
    fprintf(fp, "0\n");

    /* g -> ci */
    for(ChildAssoc *ca = children; ca; ca = ca->next_child) {
      fprintf(fp, "-%d %d 0\n", temp, ca->child->temp);
    }
    return;
  }
  case tEQUIV: {
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    ChildAssoc *ca = children;
    Gate *child1 = ca->child; ca = ca->next_child;
    Gate *child2 = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    /* g := c1 == c2 */
    /* g -> (c1 -> c2) */
    fprintf(fp, "-%d -%d %d 0\n", temp, child1->temp, child2->temp);
    /* g -> (~c1 -> ~c2) */
    fprintf(fp, "-%d %d -%d 0\n", temp, child1->temp, child2->temp);
    /* ~g -> (c1 -> ~c2) */
    fprintf(fp, "%d -%d -%d 0\n", temp, child1->temp, child2->temp);
    /* ~g -> (~c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", temp, child1->temp, child2->temp);
    return;
  }
  case tEVEN: {
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    ChildAssoc *ca = children;
    Gate *child1 = ca->child; ca = ca->next_child;
    Gate *child2 = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    /* g := c1 == c2 */
    /* g -> (c1 -> c2) */
    fprintf(fp, "-%d -%d %d 0\n", temp, child1->temp, child2->temp);
    /* g -> (~c1 -> ~c2) */
    fprintf(fp, "-%d %d -%d 0\n", temp, child1->temp, child2->temp);
    /* ~g -> (c1 -> ~c2) */
    fprintf(fp, "%d -%d -%d 0\n", temp, child1->temp, child2->temp);
    /* ~g -> (~c1 -> c2) */
    fprintf(fp, "%d %d %d 0\n", temp, child1->temp, child2->temp);
    return;
  }
  case tODD: {
    if(count_children() != 2)
      internal_error("%s:%d: not properly normalized", __FILE__,__LINE__);
    ChildAssoc *ca = children;
    Gate *child1 = ca->child; ca = ca->next_child;
    Gate *child2 = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    /* g := c1 ^ c2 */
    /* g -> (c1 -> ~c2) */
    fprintf(fp, "-%d -%d -%d 0\n", temp, child1->temp, child2->temp);
    /* g -> (~c1 -> c2) */
    fprintf(fp, "-%d %d %d 0\n", temp, child1->temp, child2->temp);
    /* ~g -> (c1 -> c2) */
    fprintf(fp, "%d -%d %d 0\n", temp, child1->temp, child2->temp);
    /* ~g -> (~c1 -> ~c2) */
    fprintf(fp, "%d %d -%d 0\n", temp, child1->temp, child2->temp);
    return;
  }
  case tITE: {
    DEBUG_ASSERT(children);
    DEBUG_ASSERT(children->next_child);
    DEBUG_ASSERT(children->next_child->next_child);
    DEBUG_ASSERT(children->next_child->next_child->next_child == 0);
    ChildAssoc *ca = children;
    Gate *if_child = ca->child; ca = ca->next_child;
    Gate *then_child = ca->child; ca = ca->next_child;
    Gate *else_child = ca->child; ca = ca->next_child;
    DEBUG_ASSERT(ca == 0);
    /* g := ITE(i,t,e) */
    /* g -> (i -> t) */
    fprintf(fp, "-%d -%d %d 0\n", temp, if_child->temp, then_child->temp);
    /* g -> (~i -> e) */
    fprintf(fp, "-%d %d %d 0\n", temp, if_child->temp, else_child->temp);
    /* ~g -> (i -> ~t) */
    fprintf(fp, "%d -%d -%d 0\n", temp, if_child->temp, then_child->temp);
    /* ~g -> (~i -> ~e) */
    fprintf(fp, "%d %d -%d 0\n", temp, if_child->temp, else_child->temp);
    return;
  }
#endif
  default:
    internal_error("%s:%d: %s NYI", __FILE__,__LINE__,typeNames[type]);
  }
  internal_error("%s:%d: %s SNH", __FILE__,__LINE__);
}
